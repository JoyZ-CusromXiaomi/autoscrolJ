# Auto Scroll Joy (web / PWA)

Scroll otomatis yang halus dengan tiga pemicu: **mata/kepala** (kamera depan), **timer**, dan **perintah suara**. HTML + CSS + JavaScript murni, tanpa build step. Tampilan Material 3 flat, terang/gelap otomatis, full-screen.

> **Penting:** halaman web hanya bisa men-scroll isinya sendiri. Aplikasi ini menggulir feed di dalamnya (12 kartu demo, atau video/foto dari galerimu). Untuk men-scroll aplikasi lain seperti TikTok/Reels/Shorts, pakai versi Android native (`AutoScrollJoy.zip`).

## Struktur

```
index.html            dashboard, layar feed, dialog pengaturan
style.css             tema M3 flat (CSS variables, dark mode)
script.js             engine scroll, timer, suara, kamera, izin
manifest.webmanifest  fullscreen, portrait, ikon
sw.js                 service worker (jalan offline)
icons/                192, 512, maskable, svg
```

## Coba di HP

Kamera dan mikrofon **hanya jalan lewat HTTPS** (atau `localhost`). Membuka `index.html` langsung dari penyimpanan (`file://`) tidak cukup.

1. Upload seluruh folder ke hosting HTTPS: Netlify (drag & drop folder), GitHub Pages, Cloudflare Pages, dsb.
2. Buka alamatnya di Chrome HP → menu ⋮ → **Instal aplikasi** (mode layar penuh tanpa bilah browser).

Tes lokal di komputer: `python3 -m http.server 8080` lalu buka `http://localhost:8080`.

## Jadikan APK

**PWABuilder (disarankan):** buka pwabuilder.com → masukkan alamat HTTPS situsmu → *Package for stores* → Android. Hasilnya TWA yang berjalan di Chrome, jadi kamera, mikrofon, Web Speech, dan layar penuh semuanya bekerja.

**WebIntoApp (WebView):** bisa, dengan batasan: pakai alamat HTTPS, aktifkan izin kamera/mikrofon di pengaturan WebIntoApp, dan **Web Speech API tidak ada di Android WebView**. Mode suara otomatis dimatikan dengan keterangan "Tidak didukung".

## Cara kerja singkat

- **Engine scroll:** animasi `requestAnimationFrame` dengan easing. Slider *Kecepatan* mengatur durasi (1,5 dtk → 0,4 dtk), *Kehalusan* mencampur gerak linear dengan kurva smootherstep. Sentuhan jari membatalkan animasi. Ringan: tidak ada loop saat idle.
- **Timer:** 5–120 dtk (pilihan cepat 15/30/60), variasi acak ±20% opsional, garis hitung mundur di atas layar. Untuk video dari galeri, "Ikuti durasi video" membuat feed lanjut tepat saat video selesai.
- **Suara:** `webkitSpeechRecognition` terus mendengar dan restart otomatis. Kata kunci bebas (pisahkan koma), cocok per kata utuh, satu ucapan = satu scroll. Berhenti saat layar feed ditutup atau tab disembunyikan.
- **Mata/kepala:** MediaPipe Face Landmarker (diunduh dari CDN saat pertama dipakai, lalu di-cache service worker). Dua sinyal dibanding posisi netral hasil kalibrasi otomatis: iris naik (melirik ke atas) atau hidung naik (mendongak). Kedipan dan wajah yang menoleh jauh diabaikan. Analisis ±9 fps pada video 320×240.

## Yang perlu kamu setel / ketahui

- **Ambang gestur mata/kepala adalah perkiraan.** Logikanya sudah diuji dengan data wajah sintetis, tetapi belum dengan wajah asli. Nyalakan mode ini, lihat **meter di pojok layar feed**, lalu atur *Sensitivitas*; garis di meter adalah titik pemicu. Bila menunduk malah memicu, nyalakan *Balik arah gestur*.
- Model wajah butuh internet saat pertama kali. Setelah ter-cache, mode ini bisa jalan offline.
- Pengenalan suara di Chrome umumnya memakai server Google, jadi butuh internet; ada kemungkinan bunyi bip di sebagian perangkat. Huruf tunggal seperti "b" sulit dikenali.
- Layar tetap menyala selama auto scroll aktif (Wake Lock). Kamera dan suara berhenti otomatis saat kembali ke dashboard atau aplikasi ke latar belakang.
- Setelah mengubah file aplikasi, naikkan `VERSION` di `sw.js` agar pengguna mendapat versi baru.
