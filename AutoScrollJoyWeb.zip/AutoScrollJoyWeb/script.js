/* =============================================================================
   Auto Scroll Joy (web/PWA)

   Catatan penting: halaman web hanya bisa men-scroll ISINYA SENDIRI. Aplikasi ini
   menggulir feed di dalam layarnya (kartu demo atau video/foto dari galeri). Untuk
   men-scroll aplikasi lain (TikTok, Reels, Shorts) dibutuhkan versi Android native.

   Isi file:
     1. Pengaturan (localStorage)
     2. Util UI (toast, tema, layar penuh, wake lock)
     3. Konten feed (kartu demo / galeri)
     4. Engine scroll halus (requestAnimationFrame)
     5. Pemicu: timer, suara (Web Speech API), mata/kepala (MediaPipe Face Landmarker)
     6. Izin kamera & mikrofon
     7. Tampilan dashboard & pengaturan
     8. Navigasi & inisialisasi
   ============================================================================= */
(() => {
  'use strict';

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const clamp = (v, lo, hi) => Math.min(hi, Math.max(lo, v));

  /* ===========================================================================
     1. PENGATURAN
     =========================================================================== */

  const STORE_KEY = 'asj.settings.v1';

  const DEFAULTS = {
    enabled: false,
    modeEye: false,
    modeTimer: false,
    modeVoice: false,

    eyeSens: 5,          // 1..10
    eyeInvert: false,
    camPreview: true,

    speed: 5,            // 1..10
    smooth: 60,          // 0..100
    loop: true,

    timerSec: 15,        // 5..120
    timerJitter: true,
    followVideo: true,

    keywords: 'scroll, next, lanjut',
    voiceLang: 'id-ID',

    autoFullscreen: true,
    theme: 'auto'        // auto | light | dark
  };

  const S = { ...DEFAULTS };
  try {
    Object.assign(S, JSON.parse(localStorage.getItem(STORE_KEY) || '{}'));
  } catch (_) { /* localStorage bisa tidak tersedia */ }

  // Rapikan nilai yang mungkin rusak.
  S.eyeSens = clamp(+S.eyeSens || DEFAULTS.eyeSens, 1, 10);
  S.speed = clamp(+S.speed || DEFAULTS.speed, 1, 10);
  S.smooth = clamp(+S.smooth || 0, 0, 100);
  S.timerSec = clamp(+S.timerSec || DEFAULTS.timerSec, 5, 120);
  if (!['auto', 'light', 'dark'].includes(S.theme)) S.theme = 'auto';
  S.enabled = false; // selalu mulai dalam keadaan mati

  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(S)); } catch (_) { /* abaikan */ }
  }

  function set(key, value) {
    S[key] = value;
    save();
    onSettingChanged(key);
  }

  function onSettingChanged(key) {
    switch (key) {
      case 'enabled':
      case 'modeEye':
      case 'modeVoice':
      case 'modeTimer':
        applyAll();
        break;
      case 'timerSec':
      case 'timerJitter':
      case 'followVideo':
        syncMedia();
        armTimer();
        break;
      case 'voiceLang':
        restartVoice();
        break;
      case 'theme':
        applyTheme();
        break;
      case 'camPreview':
        renderCam();
        break;
      default:
        break;
    }
    renderDashboard();
  }

  /* ===========================================================================
     2. UTIL UI
     =========================================================================== */

  const root = document.documentElement;

  // --- Toast ---
  const toastEl = $('#toast');
  let toastTimer = 0;
  function toast(msg, ms = 2600) {
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), ms);
  }

  // --- Tema ---
  const THEME_LABEL = { auto: 'Otomatis', light: 'Terang', dark: 'Gelap' };
  function applyTheme() {
    if (S.theme === 'auto') delete root.dataset.theme;
    else root.dataset.theme = S.theme;
    const dark = S.theme === 'dark' ||
      (S.theme === 'auto' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    const meta = $('meta[name="theme-color"]');
    if (meta) meta.content = dark ? '#111413' : '#F7F6F2';
    const btn = $('#btnTheme');
    btn.title = `Tema: ${THEME_LABEL[S.theme]}`;
    btn.setAttribute('aria-label', `Ganti tema (sekarang: ${THEME_LABEL[S.theme]})`);
  }
  function cycleTheme() {
    const order = ['auto', 'light', 'dark'];
    set('theme', order[(order.indexOf(S.theme) + 1) % order.length]);
    toast(`Tema: ${THEME_LABEL[S.theme]}`, 1200);
  }

  // --- Layar penuh ---
  function isStandalone() {
    return window.matchMedia('(display-mode: fullscreen)').matches ||
      window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true;
  }
  function toggleFullscreen() {
    try {
      if (document.fullscreenElement) document.exitFullscreen();
      else if (root.requestFullscreen) root.requestFullscreen({ navigationUI: 'hide' }).catch(() => {});
    } catch (_) { /* tidak didukung */ }
  }

  // --- Wake lock: layar tetap menyala saat auto scroll aktif ---
  let wakeLock = null;
  async function updateWakeLock(want) {
    try {
      if (want && !wakeLock && 'wakeLock' in navigator) {
        wakeLock = await navigator.wakeLock.request('screen');
        wakeLock.addEventListener('release', () => { wakeLock = null; });
      } else if (!want && wakeLock) {
        await wakeLock.release();
        wakeLock = null;
      }
    } catch (_) { wakeLock = null; }
  }

  /* ===========================================================================
     3. KONTEN FEED
     =========================================================================== */

  const feed = $('#feed');
  const DEMO_COUNT = 12;

  /** @type {{type:'demo'|'video'|'image', url?:string, name?:string}[]} */
  let items = [];
  let objectUrls = [];

  function demoItems() {
    return Array.from({ length: DEMO_COUNT }, () => ({ type: 'demo' }));
  }

  function buildFeed() {
    feed.textContent = '';
    const n = items.length;

    items.forEach((it, i) => {
      const card = document.createElement('article');
      card.className = 'card-item';

      if (it.type === 'demo') {
        card.classList.add('demo', `c${(i % 6) + 1}`);
        card.innerHTML =
          '<div class="num"></div><div class="label"></div><div class="hint"></div>';
        $('.num', card).textContent = String(i + 1);
        $('.label', card).textContent = `Konten demo ${i + 1} dari ${n}`;
        $('.hint', card).textContent = 'Geser sendiri atau tunggu pemicu';
      } else {
        card.classList.add('media');
        let el;
        if (it.type === 'video') {
          el = document.createElement('video');
          el.src = it.url;
          el.playsInline = true;
          el.preload = 'metadata';
          el.addEventListener('ended', () => onVideoEnded(card));
        } else {
          el = document.createElement('img');
          el.src = it.url;
          el.alt = it.name || '';
          el.draggable = false;
        }
        card.appendChild(el);
        const cap = document.createElement('div');
        cap.className = 'caption';
        cap.textContent = it.name || '';
        card.appendChild(cap);
      }
      feed.appendChild(card);
    });

    shownIndex = -1;
    feed.scrollTop = 0;
    settle();
    renderDashboard();
  }

  function setItems(newItems) {
    objectUrls.forEach(u => URL.revokeObjectURL(u));
    objectUrls = newItems.filter(i => i.url).map(i => i.url);
    items = newItems;
    buildFeed();
  }

  function addFiles(fileList) {
    const added = [];
    for (const f of fileList) {
      const type = f.type.startsWith('video/') ? 'video' : f.type.startsWith('image/') ? 'image' : null;
      if (!type) continue;
      added.push({ type, url: URL.createObjectURL(f), name: f.name });
    }
    if (!added.length) { toast('File tidak didukung (pilih video atau foto)'); return; }

    const current = items.filter(i => i.type !== 'demo');
    if (!current.length) {
      setItems(added);
    } else {
      // Tambahkan tanpa membuang URL lama.
      items = current.concat(added);
      objectUrls = objectUrls.concat(added.map(i => i.url));
      buildFeed();
    }
    toast(`${added.length} file ditambahkan`);
  }

  /** Mainkan video kartu aktif, jeda yang lain. */
  function syncMedia() {
    const idx = currentIndex();
    const followEnd = S.enabled && S.modeTimer && S.followVideo;
    $$('video', feed).forEach(v => {
      const card = v.closest('.card-item');
      const isCurrent = card === feed.children[idx];
      v.loop = !followEnd;
      if (isCurrent && stageOpen && !document.hidden) {
        v.muted = false;
        const p = v.play();
        if (p && p.catch) {
          p.catch(() => { v.muted = true; v.play().catch(() => {}); });
        }
      } else {
        v.pause();
        if (!isCurrent) { try { v.currentTime = 0; } catch (_) { /* belum siap */ } }
      }
    });
  }

  function onVideoEnded(card) {
    if (!(S.enabled && S.modeTimer && S.followVideo)) return;
    if (card !== feed.children[currentIndex()]) return;
    scrollNext('video-selesai');
  }

  /* ===========================================================================
     4. ENGINE SCROLL HALUS
     =========================================================================== */

  const MIN_GAP_MS = 900;   // jeda minimum antar scroll dari sumber mana pun
  let lastScrollAt = 0;
  let anim = null;
  let shownIndex = -1;

  /** Durasi satu perpindahan: kecepatan 1 -> 1500 ms, 10 -> 380 ms. */
  function durationMs() {
    return Math.round(1500 - (S.speed - 1) * ((1500 - 380) / 9));
  }

  /** Easing: campuran linear dan smootherstep sesuai slider kehalusan. */
  function ease(t) {
    const s = S.smooth / 100;
    const smoother = t * t * t * (t * (t * 6 - 15) + 10);
    return t + (smoother - t) * s;
  }

  function cardHeight() { return feed.clientHeight || window.innerHeight || 1; }
  function currentIndex() { return clamp(Math.round(feed.scrollTop / cardHeight()), 0, Math.max(0, feed.children.length - 1)); }

  function cancelAnim() {
    if (!anim) return;
    cancelAnimationFrame(anim.raf);
    anim = null;
    feed.style.scrollSnapType = '';
  }

  /** Gulir feed ke posisi [target] dengan easing; snap dimatikan selama animasi. */
  function animateTo(target, dur) {
    cancelAnim();
    const from = feed.scrollTop;
    const delta = target - from;
    if (Math.abs(delta) < 1) { settle(); return; }

    feed.style.scrollSnapType = 'none';
    const t0 = performance.now();
    const state = { raf: 0 };
    anim = state;

    const step = (now) => {
      if (anim !== state) return;
      const t = clamp((now - t0) / dur, 0, 1);
      feed.scrollTop = from + delta * ease(t);
      if (t < 1) {
        state.raf = requestAnimationFrame(step);
      } else {
        anim = null;
        feed.scrollTop = target;
        feed.style.scrollSnapType = '';
        settle();
      }
    };
    state.raf = requestAnimationFrame(step);
  }

  /**
   * Pindah ke kartu berikutnya.
   * @param {string} source asal pemicu (untuk log)
   * @param {{force?:boolean}} opts force = abaikan sakelar utama (tombol manual/uji)
   * @returns {boolean} true bila gerakan dimulai
   */
  function scrollNext(source, { force = false } = {}) {
    if (!stageOpen) return false;
    if (!force && !S.enabled) return false;
    if (anim) return false;

    const now = performance.now();
    if (now - lastScrollAt < MIN_GAP_MS) return false;

    const n = feed.children.length;
    const i = currentIndex();
    const h = cardHeight();

    if (i >= n - 1) {
      if (!S.loop || n < 2) { toast('Sudah di konten terakhir'); return false; }
      lastScrollAt = now;
      animateTo(0, Math.round(durationMs() * 1.6));
    } else {
      lastScrollAt = now;
      animateTo((i + 1) * h, durationMs());
    }
    if (window.__ASJ_DEBUG) console.log('[scroll]', source);
    return true;
  }

  /** Dipanggil saat posisi feed sudah tenang: perbarui penghitung, media, timer. */
  function settle() {
    const i = currentIndex();
    if (i === shownIndex) return;
    shownIndex = i;
    $('#hudCount').textContent = `${i + 1}/${Math.max(1, feed.children.length)}`;
    syncMedia();
    armTimer();
  }

  let scrollDebounce = 0;
  feed.addEventListener('scroll', () => {
    clearTimeout(scrollDebounce);
    scrollDebounce = setTimeout(() => { if (!anim) settle(); }, 120);
  }, { passive: true });

  // Sentuhan/roda mouse dari pengguna membatalkan animasi otomatis.
  ['touchstart', 'wheel', 'pointerdown'].forEach(ev =>
    feed.addEventListener(ev, () => { if (anim) cancelAnim(); }, { passive: true }));

  /* ===========================================================================
     5a. PEMICU: TIMER
     =========================================================================== */

  let timerId = 0;
  const barEl = $('#timerBar i');

  function resetBar() {
    barEl.style.transition = 'none';
    barEl.style.transform = 'scaleX(0)';
  }
  function startBar(ms) {
    resetBar();
    void barEl.offsetWidth; // paksa reflow agar transisi dimulai dari nol
    barEl.style.transition = `transform ${ms}ms linear`;
    barEl.style.transform = 'scaleX(1)';
  }

  function armTimer() {
    clearTimeout(timerId);
    timerId = 0;
    resetBar();
    if (!(S.enabled && S.modeTimer && stageOpen && !document.hidden)) return;

    const card = feed.children[currentIndex()];
    // Kartu video + "ikuti durasi video": event 'ended' yang memicu scroll, bukan timer.
    if (S.followVideo && card && card.querySelector('video')) return;

    const factor = S.timerJitter ? 0.8 + Math.random() * 0.4 : 1;
    const ms = Math.round(S.timerSec * 1000 * factor);
    startBar(ms);
    timerId = setTimeout(() => {
      timerId = 0;
      if (!scrollNext('timer')) armTimer();
    }, ms);
  }

  /* ===========================================================================
     5b. PEMICU: SUARA (Web Speech API)
     =========================================================================== */

  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  const VOICE_COOLDOWN_MS = 1200;

  let rec = null;
  let voiceWanted = false;
  let voiceRestartTimer = 0;
  let voiceErrors = 0;
  let lastVoiceHit = 0;
  let handledResults = new Set();

  const NON_WORD = /[^\p{L}\p{N}]+/gu;
  const normalize = (s) => String(s).toLowerCase().replace(NON_WORD, ' ').trim();

  function keywordList() {
    return String(S.keywords)
      .split(/[,;\n]/)
      .map(normalize)
      .filter(Boolean)
      .filter((k, i, a) => a.indexOf(k) === i);
  }

  /** Cocok per kata utuh. @returns kata kunci yang cocok atau null */
  function matchKeyword(text) {
    const padded = ` ${normalize(text)} `;
    return keywordList().find(k => padded.includes(` ${k} `)) || null;
  }

  function startVoice() {
    voiceWanted = true;
    if (!SR || rec || voiceRestartTimer) return;
    beginVoice();
  }

  function beginVoice() {
    voiceRestartTimer = 0;
    if (!voiceWanted || !SR) return;

    const r = new SR();
    rec = r;
    handledResults = new Set();
    r.lang = S.voiceLang;
    r.continuous = true;
    r.interimResults = true;
    r.maxAlternatives = 3;

    r.onresult = (e) => {
      voiceErrors = 0;
      for (let i = e.resultIndex; i < e.results.length; i++) {
        if (handledResults.has(i)) continue;
        const res = e.results[i];
        for (let j = 0; j < res.length; j++) {
          const hit = matchKeyword(res[j].transcript);
          if (!hit) continue;
          handledResults.add(i); // satu ucapan = satu scroll
          const now = performance.now();
          if (now - lastVoiceHit > VOICE_COOLDOWN_MS) {
            lastVoiceHit = now;
            scrollNext(`suara:${hit}`);
          }
          break;
        }
      }
    };

    r.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        voiceWanted = false;
        permStatus.microphone = 'denied';
        toast('Izin mikrofon ditolak');
        set('modeVoice', false);
      } else if (e.error === 'network') {
        voiceErrors++;
        if (voiceErrors === 1) toast('Pengenalan suara butuh internet');
      } else if (e.error === 'audio-capture') {
        toast('Mikrofon tidak ditemukan');
      }
      // 'no-speech' dan 'aborted' normal: onend akan memulai ulang.
    };

    r.onend = () => {
      if (rec === r) rec = null;
      if (voiceWanted) {
        voiceRestartTimer = setTimeout(beginVoice, Math.min(300 + voiceErrors * 700, 5000));
      }
    };

    try {
      r.start();
    } catch (_) {
      rec = null;
      voiceRestartTimer = setTimeout(beginVoice, 1000);
    }
  }

  function stopVoice() {
    voiceWanted = false;
    clearTimeout(voiceRestartTimer);
    voiceRestartTimer = 0;
    if (rec) {
      const r = rec;
      rec = null;
      r.onend = null;
      try { r.abort(); } catch (_) { /* sudah berhenti */ }
    }
  }

  function restartVoice() {
    if (voiceWanted) { stopVoice(); startVoice(); }
  }

  /* ===========================================================================
     5c. PEMICU: MATA / KEPALA (kamera depan + MediaPipe Face Landmarker)

     Dua sinyal dibandingkan terhadap posisi "netral" hasil kalibrasi:
       - mata  : posisi iris di dalam kelopak (naik saat melirik ke atas)
       - kepala: posisi ujung hidung di antara garis mata dan dagu (naik saat mendongak)
     Skor >= 1 selama HOLD_MS memicu scroll satu kali; skor harus turun < 0.5 untuk
     bisa memicu lagi. Nilai ambang adalah perkiraan; setel lewat slider Sensitivitas
     sambil melihat meter di pojok layar feed.
     =========================================================================== */

  const MP_VERSION = '0.10.14';
  const MP_BASE = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MP_VERSION}`;
  const MP_MODEL = 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/1/face_landmarker.task';

  const CALIB_FRAMES = 10;
  const HOLD_MS = 250;
  const EYE_COOLDOWN_MS = 1500;
  const DETECT_INTERVAL_MS = 110; // ~9 fps, cukup dan hemat baterai

  const camVideo = $('#camVideo');
  const camBox = $('#camBox');
  const camMeter = $('#camMeter');
  const camStatus = $('#camStatus');

  const cam = {
    token: 0, running: false, stream: null, timer: 0, landmarker: null,
    calib: 0, baseEye: 0, baseHead: 0, sEye: null, sHead: null,
    armed: true, holdAt: 0, lastTrigger: 0, lastVideoTime: -1
  };

  let landmarkerPromise = null;

  function loadLandmarker() {
    if (!landmarkerPromise) {
      landmarkerPromise = (async () => {
        const vision = await import(`${MP_BASE}/+esm`);
        const fileset = await vision.FilesetResolver.forVisionTasks(`${MP_BASE}/wasm`);
        const options = (delegate) => ({
          baseOptions: { modelAssetPath: MP_MODEL, delegate },
          runningMode: 'VIDEO',
          numFaces: 1,
          outputFaceBlendshapes: false,
          outputFacialTransformationMatrixes: false
        });
        try {
          return await vision.FaceLandmarker.createFromOptions(fileset, options('GPU'));
        } catch (_) {
          return await vision.FaceLandmarker.createFromOptions(fileset, options('CPU'));
        }
      })().catch((err) => { landmarkerPromise = null; throw err; });
    }
    return landmarkerPromise;
  }

  function thresholds() {
    const s = S.eyeSens;
    return { eye: 0.20 - 0.016 * (s - 1), head: 0.12 - 0.0095 * (s - 1) };
  }

  function resetCalibration() {
    cam.calib = 0; cam.baseEye = 0; cam.baseHead = 0;
    cam.sEye = null; cam.sHead = null;
    cam.armed = true; cam.holdAt = 0;
  }

  function setCamStatus(text) { camStatus.textContent = text; }
  function setMeter(score) {
    camMeter.style.width = `${clamp(score / 1.5, 0, 1) * 100}%`;
  }

  function renderCam() {
    camBox.hidden = !(cam.running && S.camPreview && stageOpen);
  }

  async function startEye() {
    if (cam.running) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      toast('Kamera butuh HTTPS atau browser yang mendukung');
      set('modeEye', false);
      return;
    }
    cam.running = true;
    const my = ++cam.token;
    resetCalibration();
    setMeter(0);
    setCamStatus('Menyalakan kamera…');
    renderCam();

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 320 }, height: { ideal: 240 }, frameRate: { ideal: 15 } },
        audio: false
      });
      if (my !== cam.token) { stream.getTracks().forEach(t => t.stop()); return; }
      cam.stream = stream;
      permStatus.camera = 'granted';
      camVideo.srcObject = stream;
      await camVideo.play();

      setCamStatus('Memuat model wajah…');
      const landmarker = await loadLandmarker();
      if (my !== cam.token) return;
      cam.landmarker = landmarker;
      setCamStatus('Kalibrasi: tatap layar…');
      detectLoop(my);
    } catch (err) {
      if (my !== cam.token) return;
      console.warn('[kamera]', err);
      const denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
      if (denied) permStatus.camera = 'denied';
      toast(denied ? 'Izin kamera ditolak' : 'Gagal memuat kamera atau model wajah. Periksa koneksi internet.', 3600);
      stopEye();
      set('modeEye', false);
    }
  }

  function stopEye() {
    cam.token++;
    cam.running = false;
    clearTimeout(cam.timer);
    if (cam.stream) { cam.stream.getTracks().forEach(t => t.stop()); cam.stream = null; }
    camVideo.srcObject = null;
    cam.lastVideoTime = -1;
    renderCam();
  }

  function detectLoop(my) {
    if (my !== cam.token) return;
    cam.timer = setTimeout(() => detectLoop(my), DETECT_INTERVAL_MS);

    if (camVideo.readyState < 2 || camVideo.currentTime === cam.lastVideoTime) return;
    cam.lastVideoTime = camVideo.currentTime;

    let result;
    try { result = cam.landmarker.detectForVideo(camVideo, performance.now()); }
    catch (_) { return; }

    const face = result && result.faceLandmarks && result.faceLandmarks[0];
    if (!face) {
      cam.holdAt = 0;
      setMeter(0);
      if (cam.calib >= CALIB_FRAMES) setCamStatus('Wajah tidak terdeteksi');
      return;
    }
    const m = faceMetrics(face);
    if (m) processSignal(m);
  }

  /** @returns {{eye:number|null, head:number}|null} null bila kedip atau wajah menoleh jauh */
  function faceMetrics(f) {
    const faceH = f[152].y - f[10].y;
    if (faceH <= 0.05) return null;

    // Wajah menoleh ke samping: pengukuran vertikal jadi tidak andal.
    const yaw = (f[1].x - f[234].x) / ((f[454].x - f[234].x) || 1);
    if (Math.abs(yaw - 0.5) > 0.2) return null;

    // Posisi iris dalam kelopak (hanya bila model memberi 478 titik).
    let eye = null;
    if (f.length >= 478) {
      let sum = 0;
      for (const [iris, up, lo] of [[468, 159, 145], [473, 386, 374]]) {
        const open = f[lo].y - f[up].y;
        if (open / faceH < 0.025) return null; // sedang berkedip
        sum += (f[iris].y - f[up].y) / open;
      }
      eye = sum / 2;
    }

    const eyeMid = (f[33].y + f[263].y) / 2;
    const head = (f[1].y - eyeMid) / ((f[152].y - eyeMid) || 1);
    return { eye, head };
  }

  function processSignal({ eye, head }) {
    const k = S.eyeInvert ? -1 : 1;
    const a = 0.5; // penghalusan
    cam.sEye = eye == null ? null : (cam.sEye == null ? eye : cam.sEye + (eye - cam.sEye) * a);
    cam.sHead = cam.sHead == null ? head : cam.sHead + (head - cam.sHead) * a;

    if (cam.calib < CALIB_FRAMES) {
      cam.baseEye = cam.sEye == null ? 0 : (cam.baseEye * cam.calib + cam.sEye) / (cam.calib + 1);
      cam.baseHead = (cam.baseHead * cam.calib + cam.sHead) / (cam.calib + 1);
      cam.calib++;
      if (cam.calib === CALIB_FRAMES) setCamStatus('Siap · lirik atas / dongak untuk scroll');
      return;
    }

    const th = thresholds();
    const scoreEye = cam.sEye == null ? 0 : (k * (cam.baseEye - cam.sEye)) / th.eye;
    const scoreHead = (k * (cam.baseHead - cam.sHead)) / th.head;
    const score = Math.max(scoreEye, scoreHead);
    setMeter(score);
    if (cam.calib >= CALIB_FRAMES) setCamStatus('Siap · lirik atas / dongak untuk scroll');

    const now = performance.now();

    if (score < 0.5) {
      // Zona netral: ikuti pergeseran pelan dan aktifkan kembali pemicu.
      if (cam.sEye != null) cam.baseEye += (cam.sEye - cam.baseEye) * 0.03;
      cam.baseHead += (cam.sHead - cam.baseHead) * 0.03;
      cam.armed = true;
      cam.holdAt = 0;
      return;
    }
    if (!cam.armed || score < 1) { cam.holdAt = 0; return; }

    if (!cam.holdAt) {
      cam.holdAt = now;
    } else if (now - cam.holdAt >= HOLD_MS && now - cam.lastTrigger >= EYE_COOLDOWN_MS) {
      cam.armed = false;
      cam.lastTrigger = now;
      cam.holdAt = 0;
      scrollNext('mata');
    }
  }

  /* ===========================================================================
     6. IZIN KAMERA & MIKROFON
     =========================================================================== */

  /** granted | denied | prompt | unknown | unavailable */
  const permStatus = { camera: 'unknown', microphone: 'unknown' };

  async function initPermissions() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      permStatus.camera = permStatus.microphone = 'unavailable';
      return;
    }
    for (const name of ['camera', 'microphone']) {
      try {
        const status = await navigator.permissions.query({ name });
        permStatus[name] = status.state;
        status.onchange = () => { permStatus[name] = status.state; renderDashboard(); };
      } catch (_) { /* Safari/Firefox: tidak bisa dicek tanpa meminta */ }
    }
  }

  async function requestPermission(kind) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      permStatus.camera = permStatus.microphone = 'unavailable';
      renderDashboard();
      return false;
    }
    const name = kind === 'camera' ? 'camera' : 'microphone';
    try {
      const stream = await navigator.mediaDevices.getUserMedia(
        kind === 'camera' ? { video: { facingMode: 'user' } } : { audio: true });
      stream.getTracks().forEach(t => t.stop());
      permStatus[name] = 'granted';
      renderDashboard();
      return true;
    } catch (err) {
      const denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
      permStatus[name] = denied ? 'denied' : 'unavailable';
      renderDashboard();
      return false;
    }
  }

  /* ===========================================================================
     7. TAMPILAN DASHBOARD
     =========================================================================== */

  const el = {
    swMaster: $('#swMaster'), masterStatus: $('#masterStatus'),
    swEye: $('#swEye'), swTimer: $('#swTimer'), swVoice: $('#swVoice'),
    timerSub: $('#timerSub'), voiceSub: $('#voiceSub'),
    dotCamera: $('#dotCamera'), stateCamera: $('#stateCamera'), btnCamera: $('#btnCamera'),
    dotMic: $('#dotMic'), stateMic: $('#stateMic'), btnMic: $('#btnMic'),
    permHint: $('#permHint'), contentSummary: $('#contentSummary'),
    hudToggle: $('#hudToggle')
  };

  const voiceSupported = !!SR;

  function renderPermRow(dot, stateEl, btn, status) {
    const map = {
      granted: ['on', 'Diizinkan', 'Aktif', true],
      denied: ['bad', 'Ditolak. Ubah lewat setelan situs/aplikasi', 'Coba lagi', false],
      prompt: ['', 'Belum diizinkan', 'Izinkan', false],
      unknown: ['', 'Belum diizinkan', 'Izinkan', false],
      unavailable: ['bad', 'Tidak tersedia (butuh HTTPS)', 'Coba lagi', false]
    };
    const [cls, text, label, disabled] = map[status] || map.unknown;
    dot.className = `dot ${cls}`.trim();
    stateEl.textContent = text;
    btn.textContent = label;
    btn.disabled = disabled;
  }

  function renderDashboard() {
    // Sakelar
    el.swMaster.checked = S.enabled;
    el.swEye.checked = S.modeEye;
    el.swTimer.checked = S.modeTimer;
    el.swVoice.checked = S.modeVoice;
    el.swVoice.disabled = !voiceSupported;

    // Status utama
    const modes = [];
    if (S.modeEye) modes.push('Mata/kepala');
    if (S.modeTimer) modes.push('Timer');
    if (S.modeVoice) modes.push('Suara');
    el.masterStatus.textContent =
      !S.enabled ? 'Nonaktif'
        : !modes.length ? 'Aktif, tapi belum ada mode pemicu'
          : `Aktif · ${modes.join(', ')}`;

    // Sub-teks mode
    el.timerSub.textContent = `Scroll otomatis setiap ${S.timerSec} detik`;
    el.voiceSub.textContent = voiceSupported
      ? 'Ucapkan kata kunci untuk scroll'
      : 'Tidak didukung di browser/WebView ini';

    // Izin
    renderPermRow(el.dotCamera, el.stateCamera, el.btnCamera, permStatus.camera);
    renderPermRow(el.dotMic, el.stateMic, el.btnMic, permStatus.microphone);

    const hint =
      permStatus.camera === 'unavailable' || permStatus.microphone === 'unavailable'
        ? 'Kamera dan mikrofon hanya bekerja lewat HTTPS (atau localhost). Buka aplikasi dari alamat https://.'
        : (permStatus.camera === 'denied' || permStatus.microphone === 'denied')
          ? 'Izin yang ditolak hanya bisa diubah dari setelan situs di browser, atau setelan aplikasi bila sudah dipasang.'
          : '';
    el.permHint.textContent = hint;
    el.permHint.hidden = !hint;

    // Konten
    const media = items.filter(i => i.type !== 'demo').length;
    el.contentSummary.textContent = media
      ? `${media} file dari galeri`
      : `${items.length} kartu demo`;

    // HUD
    el.hudToggle.classList.toggle('on', S.enabled);
    el.hudToggle.querySelector('use').setAttribute('href', S.enabled ? '#i-pause' : '#i-play');
    el.hudToggle.setAttribute('aria-pressed', String(S.enabled));

    // Dialog: sinkronkan nilai dan label
    $$('[data-bind]').forEach(input => {
      const key = input.dataset.bind;
      if (input.type === 'checkbox') input.checked = !!S[key];
      else if (input !== document.activeElement) input.value = S[key];
    });
    $$('[data-label]').forEach(span => { span.textContent = formatLabel(span.dataset.label); });
    $$('.chip').forEach(c => c.classList.toggle('active', +c.dataset.sec === S.timerSec));
  }

  function formatLabel(key) {
    switch (key) {
      case 'eyeSens':
      case 'speed': return `${S[key]}/10`;
      case 'smooth': return `${S.smooth}%`;
      case 'timerSec': return `${S.timerSec} dtk`;
      default: return String(S[key]);
    }
  }

  /** Terapkan semua perubahan keadaan ke mesin pemicu. */
  function applyAll() {
    const live = S.enabled && stageOpen && !document.hidden;
    if (live && S.modeEye) startEye(); else stopEye();
    if (live && S.modeVoice) startVoice(); else stopVoice();
    syncMedia();
    armTimer();
    updateWakeLock(live);
  }

  /* ===========================================================================
     8. NAVIGASI & INISIALISASI
     =========================================================================== */

  const dashboard = $('#dashboard');
  const stage = $('#stage');
  const hud = $('#hud');
  const dlg = $('#settings');

  let stageOpen = false;
  let savedIndex = 0;
  let hudTimer = 0;

  function showHud() {
    hud.classList.remove('is-hidden');
    clearTimeout(hudTimer);
    hudTimer = setTimeout(() => hud.classList.add('is-hidden'), 3500);
  }

  function openStage() {
    if (stageOpen) return;
    stageOpen = true;
    history.pushState({ stage: true }, '');
    dashboard.hidden = true;
    stage.hidden = false;

    // Posisi scroll hilang saat elemen disembunyikan: pulihkan.
    feed.style.scrollSnapType = 'none';
    feed.scrollTop = savedIndex * cardHeight();
    feed.style.scrollSnapType = '';
    shownIndex = -1;
    settle();

    if (S.autoFullscreen && !isStandalone() && !document.fullscreenElement) toggleFullscreen();
    showHud();
    applyAll();
    renderCam();
  }

  function closeStage(fromPopState = false) {
    if (!stageOpen) return;
    savedIndex = currentIndex();
    cancelAnim();
    stageOpen = false;
    stage.hidden = true;
    dashboard.hidden = false;
    if (!fromPopState) history.back();
    applyAll();
    renderCam();
  }

  window.addEventListener('popstate', () => {
    if (dlg.open) dlg.close();
    if (stageOpen) closeStage(true);
  });

  document.addEventListener('visibilitychange', applyAll);
  window.addEventListener('pagehide', () => { stopEye(); stopVoice(); });

  // HUD tampil lagi saat layar disentuh
  stage.addEventListener('pointerdown', showHud);

  /* --- Tombol --- */

  $('#btnOpenStage').addEventListener('click', openStage);
  $('#hudBack').addEventListener('click', () => closeStage());
  $('#hudToggle').addEventListener('click', () => { set('enabled', !S.enabled); showHud(); });
  $('#hudNext').addEventListener('click', () => { scrollNext('manual', { force: true }); showHud(); });
  $('#hudFullscreen').addEventListener('click', toggleFullscreen);
  $('#btnFullscreenTop').addEventListener('click', toggleFullscreen);
  $('#btnTheme').addEventListener('click', cycleTheme);

  const openSettings = () => { if (!dlg.open) dlg.showModal(); };
  $('#btnOpenSettings').addEventListener('click', openSettings);
  $('#hudSettings').addEventListener('click', openSettings);
  $('#btnCloseSettings').addEventListener('click', () => dlg.close());
  dlg.addEventListener('click', (e) => { if (e.target === dlg) dlg.close(); });

  $('#btnRecalibrate').addEventListener('click', () => {
    resetCalibration();
    setCamStatus('Kalibrasi: tatap layar…');
    toast('Tatap layar 1–2 detik');
  });

  $('#btnTest').addEventListener('click', () => {
    dlg.close();
    openStage();
    toast('Uji scroll…', 1200);
    setTimeout(() => scrollNext('uji', { force: true }), 900);
  });

  $$('.chip').forEach(chip =>
    chip.addEventListener('click', () => set('timerSec', +chip.dataset.sec)));

  /* --- Izin --- */

  $('#btnCamera').addEventListener('click', () => requestPermission('camera'));
  $('#btnMic').addEventListener('click', () => requestPermission('microphone'));

  /* --- Sakelar utama & mode --- */

  el.swMaster.addEventListener('change', () => set('enabled', el.swMaster.checked));

  el.swEye.addEventListener('change', async () => {
    if (!el.swEye.checked) { set('modeEye', false); return; }
    if (permStatus.camera !== 'granted' && !(await requestPermission('camera'))) {
      el.swEye.checked = false;
      toast('Izin kamera diperlukan untuk mode ini');
      return;
    }
    set('modeEye', true);
  });

  el.swTimer.addEventListener('change', () => set('modeTimer', el.swTimer.checked));

  el.swVoice.addEventListener('change', async () => {
    if (!el.swVoice.checked) { set('modeVoice', false); return; }
    if (!voiceSupported) {
      el.swVoice.checked = false;
      toast('Browser ini tidak mendukung pengenalan suara');
      return;
    }
    if (permStatus.microphone !== 'granted' && !(await requestPermission('microphone'))) {
      el.swVoice.checked = false;
      toast('Izin mikrofon diperlukan untuk mode ini');
      return;
    }
    set('modeVoice', true);
  });

  /* --- Konten --- */

  const fileInput = $('#fileInput');
  $('#btnAddMedia').addEventListener('click', () => fileInput.click());
  fileInput.addEventListener('change', () => {
    if (fileInput.files && fileInput.files.length) addFiles(fileInput.files);
    fileInput.value = '';
  });
  $('#btnResetMedia').addEventListener('click', () => {
    savedIndex = 0;
    setItems(demoItems());
    toast('Kembali ke kartu demo');
  });

  /* --- Kontrol di dialog (atribut data-bind) --- */

  $$('[data-bind]').forEach(input => {
    const key = input.dataset.bind;
    const evt = input.type === 'range' || input.type === 'text' ? 'input' : 'change';
    input.addEventListener(evt, () => {
      let value;
      if (input.type === 'checkbox') value = input.checked;
      else if (input.type === 'range') value = +input.value;
      else value = input.value;
      set(key, value);
    });
  });

  /* --- Mulai --- */

  async function init() {
    applyTheme();
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', applyTheme);

    setItems(demoItems());
    renderDashboard();

    await initPermissions();

    // Bersihkan mode yang tidak lagi valid (izin dicabut / API tidak ada).
    if (S.modeEye && (permStatus.camera === 'denied' || permStatus.camera === 'prompt')) S.modeEye = false;
    if (S.modeVoice && (!voiceSupported || permStatus.microphone === 'denied' || permStatus.microphone === 'prompt')) S.modeVoice = false;
    save();
    renderDashboard();

    if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      navigator.serviceWorker.register('sw.js').catch(() => { /* offline mode opsional */ });
    }
  }

  init();
})();
